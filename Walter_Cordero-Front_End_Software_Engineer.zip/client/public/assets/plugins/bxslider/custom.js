$('#imgsProperty').bxSlider({
  mode: 'fade',
  auto: true,
  autoControls: true,
  pause: 2000
});
